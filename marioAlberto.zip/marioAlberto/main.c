#include <stdio.h>
#include <stdlib.h>
#include "alumno.h"
void mostrar(Alumno* array[],int cantidad);
void cargar(Alumno** array,int cantidadMaxima,int* cantidadActual);

int main()
{

    Alumno* arrayPunteroAlumnos[4000];
    int qtyActualArrayAlumnos = 0;
    int qtyMaximaArrayAlumnos = 4000;

    cargar(arrayPunteroAlumnos,qtyMaximaArrayAlumnos,&qtyActualArrayAlumnos);
    mostrar(arrayPunteroAlumnos,qtyActualArrayAlumnos);
    //modificar(arrayPunteroAlumnos,qtyActualArrayAlumnos);

   // mostrar(arrayPunteroAlumnos,qtyActualArrayAlumnos);
    return 0;
}


void cargar(Alumno** array,int cantidadMaxima,int* cantidadActual)
{
    /*
    int i;
    for(i=0;i<40;i++)
    {
        arrayAlumno_add(array, cantidadMaxima, cantidadActual, "28000555", "JUAN", "PEREZ", "20-28000555-6", i, -1);
    }*/
    FILE* fp;
    int aux1,i=0;
    char aux2[50];
    char aux3[50];
    char aux4[50];
    char aux5[50];
    fp = fopen("pepe.txt","r");
    if(fp!=NULL)
    {
        do
        {
            fscanf(fp,"%d,%[^,],%[^,],%[^,],%[^\n]\n",&aux1,aux2,aux3,aux4,aux5);
                arrayAlumno_add(array, cantidadMaxima, cantidadActual,"55555555", aux5, aux2, aux3, 55555555, aux1);
        }while(!feof(fp));
        fclose(fp);

    }


}

void mostrar(Alumno* array[],int cantidad)
{
    int i;
    char cuit[50];
    float altura;
    for(i=0;i<cantidad;i++)
    {
        alumno_getCuit(array[i],cuit);
        alumno_getAltura(array[i],&altura);
        printf("\nCuit:%s-Altura:%f",cuit,altura);
    }
}

void modificar(Alumno* array[],int cantidad)
{
    int i;
    Alumno* auxiliarAlumno;
    for(i=5;i<10;i++)
    {
        auxiliarAlumno = arrayAlumno_getById(array,cantidad,i);
        if(auxiliarAlumno != NULL)
        {
            alumno_setAltura(auxiliarAlumno,88);
        }
    }
}
