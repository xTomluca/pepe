#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
#include "Employee.h"


int parserEmployee(FILE* pFile , ArrayList* pArrayListEmployee)
{
    char bId[4096];
    char bName[4096];
    char bLastName[4096];
    char bIsEmpty[4096];

    int retorno=-1;

    if(pFile!=NULL && pArrayListEmployee!=NULL)
    {
        retorno=0;
        do
        {
            fscanf(pFile,"%[^,],%[^,],%[^,],%[^\n]\n",bId,bName,bLastName,bIsEmpty);
            al_add(pArrayListEmployee,employee_newParametros(bId,bName,bLastName,bIsEmpty));
        }
        while(!feof(pFile));

    }
    return 0;
}
