#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
#include "Employee.h"
#include <string.h>
#include <ctype.h>

int isValidName(char* name);
static int isValidLastName(char* lastName);

int employee_compareName(Employee* pEmployeeA,Employee* pEmployeeB)
{
    char nameEmployeeA[51];
    char nameEmployeeB[51];
    int retorno = 0;

    if (pEmployeeA != NULL && pEmployeeB != NULL)
    {
        employee_getName(pEmployeeA,nameEmployeeA);
        employee_getName(pEmployeeB,nameEmployeeA);

}

int employee_compare(Employee* pEmployeeA,Employee* pEmployeeB)
{
    int idEmployeeA;
    int idEmployeeB;
    int retorno = 0;

    if (pEmployeeA != NULL && pEmployeeB != NULL)
    {
        employee_getId(pEmployeeA,idEmployeeA);
        employee_getId(pEmployeeB,idEmployeeB);

        if(idEmployeeA>idEmployeeB)
        {
            retorno=1;
        }else if(idEmployeeA<idEmployeeB)
        {
            retorno=-1;
        }
    }
    return retorno;
}


void employee_print(Employee* this)
{
    int id;
    char name[51];
    char lastName[51];
    int isEmpty;

    if(this != NULL)
    {
        employee_getId(this,&id);
        employee_getName(this,name);
        employee_getLastName(this,lastName);
        employee_getIsEmpty(this,&isEmpty);

        printf("\n id: %d - nombre: %s - apellido: %s isEmpty: %d\n",id,name,lastName,isEmpty);
    }
}

Employee* employee_new(void)
{

    Employee* returnAux = NULL;
    returnAux = malloc(sizeof(char));

    return returnAux;

}

Employee* employee_newParametros(char* strId, char* name, char* lastName, char* strIsEmpty)
{
    int id;
    int isEmpty;

    Employee* this = NULL;
    id = atoi(strId);
    if(!strcmp(strIsEmpty,"true"))
        isEmpty=1;

    this=employee_new();

    if( !employee_setId(this,id) &&
        !employee_setName(this,name) &&
        !employee_setLastName(this,lastName) &&
        !employee_setIsEmpty(this,isEmpty)
        )
    {
        return this;
    }
    employee_delete(this);
    return NULL;
}

void employee_delete(Employee* this)
{


}

int employee_setId(Employee* this, int* id)
{
    static int ultimoId = -1;
    int retorno=-1;
    if(this != NULL && id == -1)
    {
        retorno = 0;
        ultimoId++;
        this->id = ultimoId;
    }
    else if(this != NULL && id > ultimoId)
    {
        retorno = 0;
        ultimoId = id;
        this->id = ultimoId;
    }
    return retorno;
}

int employee_getId(Employee* this, int* id)
{
    int retorno=-1;
    if(this != NULL && id == NULL)
    {
        retorno = 0;
        *id = this->id;
    }
    return retorno;
}

int employee_setName(Employee* this, char* name)
{
    int retorno= -1;

    if(this!=NULL && name!=NULL)
    {
        if(!employee_isValidName(name))
        {
            strcpy(this->name,name);
            retorno= 0;
        }
    }
    return retorno;
}

int employee_getName(Employee* this, char* name)
{
    int retorno= -1;

    if(this != NULL && name != NULL && isValidName(name))
    {
        retorno = 0;
        *name = this->name;
    }
    return retorno;
}

int employee_isValidName(char* name)
{
    if(name!=NULL)
    {
        return 0;
    }
    return 1;
}

int employee_setLastName(Employee* this, char* lastName)
{
    int retorno= -1;

    if(this!=NULL && lastName!=NULL)
    {
        if(!isValidLastName(lastName))
        {
            strcpy(this->lastName,lastName);
            retorno= 0;
        }
    }
    return retorno;
}

int employee_getLastName(Employee* this, char* lastName)
{
    int retorno= -1;

    if(this!=NULL && lastName!=NULL)
    {
        strcpy(lastName,this->lastName);
        retorno= 0;
    }
    return retorno;
}

static int isValidLastName(char* lastName)
{
    if(lastName!=NULL)
    {
        return 0;
    }
    return 1;
}

int employee_getIsEmpty(Employee* this, int* isEmpty)
{
    int retorno=-1;
    if(this != NULL && isEmpty == NULL)
    {
        retorno = 0;
        *isEmpty = this->isEmpty;
    }
    return retorno;
}

int employee_setIsEmpty(Employee* this, int* isEmpty)
{
    int retorno=-1;
    if(this != NULL)
    {
        retorno = 0;
        this->isEmpty = isEmpty;
    }
    return retorno;
}

int isValidIsEmpty(int isEmpty)
{
    int i;
    al_add(listaEmpleados(),employee_newParametros("","","",""));

    for(i=0; i<al_len(listaEmpleados);i++)
    {
        employee_print(al_get(listaEmpleados,i));
    }
    return 0;
}









